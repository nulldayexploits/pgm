<?php
 
	$base_url_front = "http://localhost/skripsi/2022/pgm";
	$base_url_back  = $base_url_front."/admin";

?>