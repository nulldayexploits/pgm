<?php

  $databaseHost = 'localhost';
  $databaseName = '22_pgm';
  $databaseUsername = 'root';
  $databasePassword = 'palaguna_maria_33';
   
  $mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName, '3370'); 
  
  date_default_timezone_set('Asia/Makassar');

?>