<?php 

      include 'template/top.php';
      include 'config/connect-db.php';


?>


    <style type="text/css">
        table tr td{
            text-align: left;
        }
    </style>


    <section class="mbr-section mbr-section-hero mbr-section-full mbr-after-navbar" id="header1-1" style="background-color: rgb(255, 255, 255);">
        <div class="mbr-table-cell">
            <div class="container">
                <div class="row">
                    <div class="mbr-section col-md-10 col-md-offset-1 text-xs-center">
                        <h1 class="mbr-section-title display-3">
                            <center style="font-size: 50px;">SELAMAT DATANG <br>DI APLIKASI


                            </center>
                        </h1>


                                
                   
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $tinggi = '300x'; include('template/bottom.php') ?>